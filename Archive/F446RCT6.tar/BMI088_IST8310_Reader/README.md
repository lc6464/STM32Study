# STM32 Study: UART_Homework

这是一个简单的 STM32 学习项目，用于学习 BMI088 和 IST8310 传感器的读取。

## 硬件要求

- ZHKU 奇点战队 STM32F446RCT6 开发板

## 功能说明
