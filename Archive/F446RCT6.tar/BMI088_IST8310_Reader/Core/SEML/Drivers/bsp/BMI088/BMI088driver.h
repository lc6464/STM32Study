#ifndef BMI088DRIVER_H
#define BMI088DRIVER_H
#include "../../../Middlewares/Solution/AHRS/AHRS.h"
#include "../../hal/Interface/gpio_if.h"
#include "../../hal/Interface/i2c_if.h"
#include "../../hal/Interface/spi_if.h"

#define BMI088_GetTick() SEML_GetTick()
#define BMI088_Delay(delay_ms) HAL_Delay(delay_ms)

#define BMI088_TEMP_FACTOR 0.125f
#define BMI088_TEMP_OFFSET 23.0f

#define BMI088_WRITE_ACCEL_REG_NUM 6
#define BMI088_WRITE_GYRO_REG_NUM 6

#define BMI088_GYRO_DATA_READY_BIT 0
#define BMI088_ACCEL_DATA_READY_BIT 1
#define BMI088_ACCEL_TEMP_DATA_READY_BIT 2

#define BMI088_LONG_DELAY_TIME 80
#define BMI088_COM_WAIT_SENSOR_TIME 150

#define BMI088_ACCEL_IIC_ADDRESSE (0x18 << 1)
#define BMI088_GYRO_IIC_ADDRESSE (0x68 << 1)

#define BMI088_ACCEL_RANGE_3G
// #define BMI088_ACCEL_RANGE_6G
// #define BMI088_ACCEL_RANGE_12G
// #define BMI088_ACCEL_RANGE_24G

#define BMI088_GYRO_RANGE_2000
// #define BMI088_GYRO_RANGE_1000
// #define BMI088_GYRO_RANGE_500
// #define BMI088_GYRO_RANGE_250
// #define BMI088_GYRO_RANGE_125

#define BMI088_ACCEL_3G_SEN 0.0008974358974f
#define BMI088_ACCEL_6G_SEN 0.00179443359375f
#define BMI088_ACCEL_12G_SEN 0.0035888671875f
#define BMI088_ACCEL_24G_SEN 0.007177734375f

#define BMI088_GYRO_2000_SEN 0.00106526443603169529841533860381f
#define BMI088_GYRO_1000_SEN 0.00053263221801584764920766930190693f
#define BMI088_GYRO_500_SEN 0.00026631610900792382460383465095346f
#define BMI088_GYRO_250_SEN 0.00013315805450396191230191732547673f
#define BMI088_GYRO_125_SEN 0.000066579027251980956150958662738366f

#define GxOFFSET 0.000693685f
#define GyOFFSET 0.00280985f
#define GzOFFSET 0.004233f
#define gNORM 9.62609f

typedef struct {
  float Temperature;
  SPI_Handle_t SPI_Handle;
  GPIO_Handle_t CS1_Accel_handle;
  GPIO_Handle_t CS1_Gyro_handle;
} BMI088_Data_t;

enum {
  BMI088_NO_ERROR = 0x00,
  BMI088_ACC_PWR_CTRL_ERROR = 0x01,
  BMI088_ACC_PWR_CONF_ERROR = 0x02,
  BMI088_ACC_CONF_ERROR = 0x03,
  BMI088_ACC_SELF_TEST_ERROR = 0x04,
  BMI088_ACC_RANGE_ERROR = 0x05,
  BMI088_INT1_IO_CTRL_ERROR = 0x06,
  BMI088_INT_MAP_DATA_ERROR = 0x07,
  BMI088_GYRO_RANGE_ERROR = 0x08,
  BMI088_GYRO_BANDWIDTH_ERROR = 0x09,
  BMI088_GYRO_LPM1_ERROR = 0x0A,
  BMI088_GYRO_CTRL_ERROR = 0x0B,
  BMI088_GYRO_INT3_INT4_IO_CONF_ERROR = 0x0C,
  BMI088_GYRO_INT3_INT4_IO_MAP_ERROR = 0x0D,

  BMI088_SELF_TEST_ACCEL_ERROR = 0x80,
  BMI088_SELF_TEST_GYRO_ERROR = 0x40,
  BMI088_NO_SENSOR = 0xFF,
};

uint8_t BMI088_Init(BMI088_Data_t *bmi088);

/**
 * @brief 通过读取加速度数据和角速度数据
 * @param[in] bmi088 bmi088的句柄
 * @param[out] accel_data 加速度数据
 * @param[out] gyro_data 角速度数据
 * @retval none
 */
void BMI088_Read(BMI088_Data_t *bmi088, Accel_Data_t *accel_data,
                 Gyro_Data_t *gyro_data);
#endif
