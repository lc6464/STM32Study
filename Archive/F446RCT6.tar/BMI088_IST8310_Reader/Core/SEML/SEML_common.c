#include "SEML_common.h"
/**
 * @brief 临界区信号量
 */
uint8_t critical_section_count;
