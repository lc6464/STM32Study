/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.h
 * @brief          : Header for main.c file.
 *                   This file contains the common defines of the application.
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define CS_Accel_Pin GPIO_PIN_2
#define CS_Accel_GPIO_Port GPIOC
#define CS_Gyro_Pin GPIO_PIN_3
#define CS_Gyro_GPIO_Port GPIOC
#define EXTI_Accel_Pin GPIO_PIN_4
#define EXTI_Accel_GPIO_Port GPIOA
#define EXTI_Gyro_Pin GPIO_PIN_5
#define EXTI_Gyro_GPIO_Port GPIOA
#define IST8310_DReady_Pin GPIO_PIN_4
#define IST8310_DReady_GPIO_Port GPIOC
#define IST8310_Reset_Pin GPIO_PIN_5
#define IST8310_Reset_GPIO_Port GPIOC

/* USER CODE BEGIN Private defines */

#define RSTN_IST8310_Pin IST8310_Reset_Pin
#define RSTN_IST8310_GPIO_Port IST8310_Reset_GPIO_Port

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
