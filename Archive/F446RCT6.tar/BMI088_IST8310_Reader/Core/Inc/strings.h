#pragma once

#include <stdio.h>

int int32ToString(int32_t x, char str[], uint16_t d);
int int64ToString(int64_t x, char *output);
int floatToString(float x, char *output);