#ifndef __CALLBACKS_H__
#define __CALLBACKS_H__

#ifdef __cplusplus
extern "C" {
#endif

void USART1_IDLECallback(UART_HandleTypeDef *huart);

#ifdef __cplusplus
}
#endif

#endif /* __CALLBACKS_H__ */
